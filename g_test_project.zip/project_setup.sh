#!/bin/zsh
rm -rf build
mkdir build 
cd build
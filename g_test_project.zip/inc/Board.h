#ifndef __BOARD_H__
#define __BOARD_H__

#include <iostream>

class Board
{ 
private:
    static const constexpr int SIZE = 3;
    static const constexpr int DIGITS[] = {
        '0', '1', '2', '3', '4',
        '5', '6', '7', '8', '9'
    };
    int board[SIZE][SIZE];
    int mark;
public:
    Board() = default;
    ~Board() = default;
    void init();    // init board
    void draw();    // draw board on screen 
    bool check();   // check win condition
    bool update(int position); // populate with mark
};



#endif


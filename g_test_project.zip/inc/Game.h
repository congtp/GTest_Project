#ifndef __GAME_H__
#define __GAME_H__

#include "Board.h"

class Game
{
private:
    Board board_;
public:
    Game(const Board &board_);
    ~Game() = default;

    void run();
};



#endif
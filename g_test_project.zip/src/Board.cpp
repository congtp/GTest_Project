#include "Board.h"

void Board::init()
{
    mark = 'X';
    char digit = '1';
    for(auto lines = 0; lines < SIZE; lines++)
    {
        for(auto column = 0; column < SIZE; column++)
        {
            this->board[lines][column] = digit;
            digit++; 
        }
    }
}

void Board::draw()
{
   
    for(auto lines = 0; lines < SIZE; lines++)
    {
        for(auto column = 0; column < SIZE; column++)
        {
            std::cout << (char)this->board[lines][column] << " ";
        }
        std::cout << "\n";
    }
}

bool Board::check()
{
    int i = 0;
    int j = 0;
    // check lines
    for(auto i = 0; i < SIZE; i++){
        if(board[i][j] == board[i][j+1] && board[i][j] == board[i][j+2])
            return true;
        j = 0;
    }
    
    
    i = 0;
    j = 0;
    // check column
    for(auto j = 0; j < SIZE; j++){
        if(board[i][j] == board[i+1][j] && board[i][j] == board[i+2][j])
        return true;
        i = 0;
    }
    
    
    i = 0;
    j = 0;
    // check diags
    if(board[i][j] == board[i+1][j+1] && board[i][j] == board[i+2][j+2])
        return true;
    
    i = 0; 
    j = SIZE - 1;
    if(board[i][j] == board[i+1][j-1] && board[i][j] == board[i+2][j-2])
        return true;
    
    return false;
}

bool Board::update(int position)
{
    bool is_updated = false;
    for(auto lines = 0; lines < SIZE; lines++)
    {
        for(auto column = 0; column < SIZE; column++)
        {
            if(board[lines][column] == position)
            {
                board[lines][column] = mark;
                is_updated = true;
            }
        }
    }

    if (mark == 'X')
        mark = '0';
    else
        mark = 'X';
    return is_updated;
} 
#include "Game.h"

Game::Game(const Board &board_)
:board_(board_){

}

void Game::run()
{
    int moves = 0;
    while(moves < 9)
    {
        std::cout << "\n TicTacToe \n";
        this->board_.draw();
        std::cout << "\n Player " << (moves % 2 ? "2" : "1") << "\'s turn: \n";
        char position = 0;
        std::cin >> position;
        while(position <= 9 && position >= 1)
        {
            std::cout << "Invalid input" << std::endl;
            std::cin >> position;
        }
        
        if(!board_.update(position))
        {
            // Probably there is already X or 0 at the given position
            std::cout << "\n Invalid input, try again with the valid position \n ";
        }

        // chekc if somebody won only if more than 4 moves already 
        if (moves > 3)
        {
            if (board_.check())
            {
                board_.draw();
                std::cout << "\nPlayer " << (moves % 2 ? "2" : "1") << "won !\n"; 
                break;
            }
            else if (moves == 8)
            {
                std::cout << "\nIt 's a draw!\n";
            }
        }
        moves++;

    }
}

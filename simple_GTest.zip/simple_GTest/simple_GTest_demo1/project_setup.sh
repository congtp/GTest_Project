rm -rf build
mkdir build
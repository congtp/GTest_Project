#include <gtest/gtest.h>


TEST(SimpleHelloTest, BasicAssertion)
{
    // Expect two strings not to be equal.
    EXPECT_STRNE("hello", "world");
    // Expect equality.
    EXPECT_EQ(7 * 6, 42);
}

int multiplication(int a, int b)
{
    return a*b;
}


TEST(MultiplicationTest, ExpectTrueTest)
{
    // Setup Step
    const int a = 10;
    const int b = 15;

    // Action Step
    const int result = multiplication(a, b);

    // Assert Step
    EXPECT_EQ(result, 150); 
}

